﻿/**
 * ToolBox Web - Main Utility Suite & Global Application Script
 * Central site configuration, toast notifications, clipboard utilities, and UI helpers.
 */

// Centralized Site Configuration (Easily customizable by site owner)
window.SITE_CONFIG = {
  siteName: 'ToolBox Web',
  siteDomain: window.location.protocol.startsWith('http') ? window.location.origin : '',
  supportEmail: 'manojkhatri0025@gmail.com',
  socialLinks: {},
  adsenseEnabled: false, // Ad integration is deferred until the site is launched.
  adsenseClient: ''
};

// Global Toast Notification System
window.showToast = function (message, type = 'info', duration = 3200) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    container.setAttribute('aria-live', 'polite');
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  // Icon based on type
  let iconSvg = '';
  if (type === 'success') {
    iconSvg = '<svg viewBox="0 0 20 20" fill="currentColor" width="20" height="20" style="color:var(--success);flex-shrink:0;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" /></svg>';
  } else if (type === 'error') {
    iconSvg = '<svg viewBox="0 0 20 20" fill="currentColor" width="20" height="20" style="color:var(--danger);flex-shrink:0;"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" /></svg>';
  } else {
    iconSvg = '<svg viewBox="0 0 20 20" fill="currentColor" width="20" height="20" style="color:var(--primary);flex-shrink:0;"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" /></svg>';
  }

  const textSpan = document.createElement('span');
  textSpan.textContent = message;
  toast.innerHTML = iconSvg;
  toast.appendChild(textSpan);

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }, duration);
};

// Clipboard Copy Helper
window.copyToClipboard = function (text, successMsg = 'Copied to clipboard!') {
  if (!text) {
    window.showToast('Nothing to copy', 'error');
    return;
  }
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(() => {
      window.showToast(successMsg, 'success');
    }).catch(() => {
      fallbackCopy(text, successMsg);
    });
  } else {
    fallbackCopy(text, successMsg);
  }
};

function fallbackCopy(text, successMsg) {
  const textArea = document.createElement('textarea');
  textArea.value = text;
  textArea.style.position = 'fixed';
  textArea.style.left = '-999999px';
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand('copy');
    window.showToast(successMsg, 'success');
  } catch (err) {
    window.showToast('Failed to copy to clipboard', 'error');
  }
  document.body.removeChild(textArea);
}

// File Size Formatter
window.formatBytes = function (bytes, decimals = 2) {
  if (!bytes || bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

// Drag & Drop File Zone Helper
window.setupDropzone = function (dropzoneEl, fileInputEl, onFilesSelected) {
  if (!dropzoneEl || !fileInputEl) return;

  ['dragenter', 'dragover'].forEach(eventName => {
    dropzoneEl.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzoneEl.classList.add('dragover');
    }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzoneEl.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzoneEl.classList.remove('dragover');
    }, false);
  });

  dropzoneEl.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files && files.length > 0) {
      if (typeof onFilesSelected === 'function') {
        onFilesSelected(files);
      }
    }
  });

  fileInputEl.addEventListener('change', () => {
    if (fileInputEl.files && fileInputEl.files.length > 0) {
      if (typeof onFilesSelected === 'function') {
        onFilesSelected(fileInputEl.files);
      }
    }
  });
};

// Auto Initialize DOM Elements
document.addEventListener('DOMContentLoaded', () => {
  // Update copyright year dynamically
  const yearElements = document.querySelectorAll('.current-year, #current-year');
  const thisYear = new Date().getFullYear();
  yearElements.forEach(el => {
    el.textContent = thisYear;
  });

  // Setup FAQ Accordion Items
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const questionBtn = item.querySelector('.faq-question');
    if (questionBtn) {
      questionBtn.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        item.classList.toggle('open', !isOpen);
      });
    }
  });

  // Sync social links from SITE_CONFIG
  if (window.SITE_CONFIG && window.SITE_CONFIG.socialLinks) {
    const s = window.SITE_CONFIG.socialLinks;
    const fbLink = document.querySelector('a[aria-label="Facebook"]');
    if (fbLink && s.facebook) fbLink.href = s.facebook;
    const igLink = document.querySelector('a[aria-label="Instagram"]');
    if (igLink && s.instagram) igLink.href = s.instagram;
    const twLink = document.querySelector('a[aria-label="X (Twitter)"]');
    if (twLink && (s.twitter || s.x)) twLink.href = s.twitter || s.x;
    const ytLink = document.querySelector('a[aria-label="YouTube"]');
    if (ytLink && s.youtube) ytLink.href = s.youtube;
  }
});
