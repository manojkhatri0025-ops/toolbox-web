/**
 * ToolBox Web - Theme Management System (Light / Dark Mode)
 * Persists user preference via localStorage and respects OS preference.
 */
(function () {
  'use strict';

  const STORAGE_KEY = 'toolboxweb_theme';
  const LEGACY_KEYS = ['omnitools_theme', 'tools_theme'];
  const THEME_DARK = 'dark';
  const THEME_LIGHT = 'light';

  // Get initial theme
  function getPreferredTheme() {
    let storedTheme = localStorage.getItem(STORAGE_KEY);
    if (!storedTheme) {
      for (const key of LEGACY_KEYS) {
        const val = localStorage.getItem(key);
        if (val) {
          storedTheme = val;
          break;
        }
      }
    }
    if (storedTheme === THEME_DARK || storedTheme === THEME_LIGHT) {
      return storedTheme;
    }
    // Fallback to system preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return THEME_DARK;
    }
    return THEME_LIGHT;
  }

  // Apply theme to document
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const toggleBtns = document.querySelectorAll('.theme-toggle-btn');
    toggleBtns.forEach(btn => {
      btn.setAttribute('aria-label', theme === THEME_DARK ? 'Switch to light theme' : 'Switch to dark theme');
      btn.setAttribute('aria-pressed', theme === THEME_DARK ? 'true' : 'false');
    });
  }

  // Toggle theme
  function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || THEME_LIGHT;
    const newTheme = currentTheme === THEME_DARK ? THEME_LIGHT : THEME_DARK;
    localStorage.setItem(STORAGE_KEY, newTheme);
    applyTheme(newTheme);
  }

  // Initialize immediately to prevent flash of wrong theme
  const initialTheme = getPreferredTheme();
  applyTheme(initialTheme);

  // Set up event listeners once DOM is ready
  document.addEventListener('DOMContentLoaded', () => {
    // Re-apply to sync buttons
    applyTheme(document.documentElement.getAttribute('data-theme') || initialTheme);

    const toggleBtns = document.querySelectorAll('.theme-toggle-btn');
    toggleBtns.forEach(btn => {
      btn.addEventListener('click', toggleTheme);
    });

    // Listen for OS system theme changes
    if (window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem(STORAGE_KEY)) {
          applyTheme(e.matches ? THEME_DARK : THEME_LIGHT);
        }
      });
    }
  });

  // Expose toggle function globally
  window.toggleTheme = toggleTheme;
})();
