﻿/**
 * ToolBox Web - Developer Tools Suite
 * 13. JSON Formatter & Validator
 * 14. Base64 Encoder/Decoder
 * 15. URL Encoder/Decoder
 */

/* ==========================================================================
   13. JSON Formatter & Validator
   ========================================================================== */
window.initJsonFormatter = function () {
  const jsonInput = document.getElementById('json-input');
  const indentSelect = document.getElementById('json-indent');
  const formatBtn = document.getElementById('format-json-btn');
  const minifyBtn = document.getElementById('minify-json-btn');
  const validateBtn = document.getElementById('validate-json-btn');
  const copyBtn = document.getElementById('copy-json-btn');
  const clearBtn = document.getElementById('clear-json-btn');
  const errorBox = document.getElementById('json-error-box');

  if (!jsonInput) return;

  function clearError() {
    errorBox.style.display = 'none';
    errorBox.textContent = '';
  }

  function showError(msg) {
    errorBox.style.display = 'block';
    errorBox.textContent = msg;
  }

  // Validate syntax, then change whitespace only. Parsing and serializing values
  // would round large IDs and turn out-of-range numeric literals into null.
  function formatJsonText(raw, indent = '') {
    JSON.parse(raw);
    const tokens = raw.match(/"(?:[^"\\]|\\.)*"|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null|[{}\[\]:,]/g);
    if (!indent) return tokens.join('');
    let depth = 0;
    let output = '';
    tokens.forEach((token, index) => {
      const previous = tokens[index - 1];
      const next = tokens[index + 1];
      if (token === '{' || token === '[') {
        output += token;
        depth++;
        if (next !== '}' && next !== ']') output += '\n' + indent.repeat(depth);
      } else if (token === '}' || token === ']') {
        depth--;
        if (previous !== '{' && previous !== '[') output += '\n' + indent.repeat(depth);
        output += token;
      } else if (token === ',') {
        output += ',\n' + indent.repeat(depth);
      } else if (token === ':') {
        output += ': ';
      } else {
        output += token;
      }
    });
    return output;
  }

  formatBtn.addEventListener('click', () => {
    clearError();
    const raw = jsonInput.value.trim();
    if (!raw) {
      window.showToast('Please enter some JSON to format.', 'error');
      return;
    }

    try {
      const indent = indentSelect.value === 'tab' ? '\t' : ' '.repeat(parseInt(indentSelect.value, 10) || 2);
      jsonInput.value = formatJsonText(raw, indent);
      window.showToast('JSON formatted successfully!', 'success');
    } catch (err) {
      showError(`JSON Syntax Error: ${err.message}`);
      window.showToast('Invalid JSON syntax.', 'error');
    }
  });

  minifyBtn.addEventListener('click', () => {
    clearError();
    const raw = jsonInput.value.trim();
    if (!raw) return;

    try {
      jsonInput.value = formatJsonText(raw);
      window.showToast('JSON minified!', 'success');
    } catch (err) {
      showError(`JSON Syntax Error: ${err.message}`);
      window.showToast('Invalid JSON syntax.', 'error');
    }
  });

  validateBtn.addEventListener('click', () => {
    clearError();
    const raw = jsonInput.value.trim();
    if (!raw) {
      window.showToast('JSON input is empty.', 'error');
      return;
    }

    try {
      JSON.parse(raw);
      window.showToast('Valid JSON! Syntax is completely correct.', 'success');
    } catch (err) {
      showError(`Invalid JSON: ${err.message}`);
      window.showToast('JSON contains errors.', 'error');
    }
  });

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(jsonInput.value, 'JSON copied to clipboard!');
  });

  clearBtn.addEventListener('click', () => {
    jsonInput.value = '';
    clearError();
    window.showToast('JSON editor cleared', 'info');
  });
};

/* ==========================================================================
   14. Base64 Encoder/Decoder (UTF-8 Safe)
   ========================================================================== */
window.initBase64Tool = function () {
  const modeRadios = document.querySelectorAll('input[name="b64-mode"]');
  const inputEl = document.getElementById('b64-input');
  const outputEl = document.getElementById('b64-output');
  const actionBtn = document.getElementById('b64-action-btn');
  const swapBtn = document.getElementById('b64-swap-btn');
  const copyBtn = document.getElementById('copy-b64-btn');
  const clearBtn = document.getElementById('clear-b64-btn');

  if (!inputEl) return;

  // Modern UTF-8 Base64 Encoding
  function utf8ToBase64(str) {
    const bytes = new TextEncoder().encode(str);
    const binString = Array.from(bytes, (byte) => String.fromCodePoint(byte)).join('');
    return btoa(binString);
  }

  // Modern UTF-8 Base64 Decoding
  function base64ToUtf8(base64) {
    // Sanitize whitespace
    const cleanB64 = base64.replace(/\s+/g, '');
    const binString = atob(cleanB64);
    const bytes = Uint8Array.from(binString, (m) => m.codePointAt(0));
    return new TextDecoder().decode(bytes);
  }

  function getMode() {
    const checked = document.querySelector('input[name="b64-mode"]:checked');
    return checked ? checked.value : 'encode';
  }

  function process() {
    const mode = getMode();
    const val = inputEl.value;

    if (!val) {
      outputEl.value = '';
      return;
    }

    try {
      if (mode === 'encode') {
        outputEl.value = utf8ToBase64(val);
        window.showToast('Encoded to Base64!', 'success');
      } else {
        outputEl.value = base64ToUtf8(val);
        window.showToast('Decoded from Base64!', 'success');
      }
    } catch (err) {
      outputEl.value = '';
      window.showToast(`Base64 ${mode} failed: Invalid data sequence.`, 'error');
    }
  }

  modeRadios.forEach(radio => {
    radio.addEventListener('change', () => {
      const mode = getMode();
      actionBtn.textContent = mode === 'encode' ? 'Encode to Base64' : 'Decode from Base64';
    });
  });

  actionBtn.addEventListener('click', process);

  swapBtn.addEventListener('click', () => {
    const temp = inputEl.value;
    inputEl.value = outputEl.value;
    outputEl.value = temp;

    // Flip radio selection
    const mode = getMode();
    const newMode = mode === 'encode' ? 'decode' : 'encode';
    document.querySelector(`input[name="b64-mode"][value="${newMode}"]`).checked = true;
    actionBtn.textContent = newMode === 'encode' ? 'Encode to Base64' : 'Decode from Base64';
  });

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(outputEl.value, 'Output copied to clipboard!');
  });

  clearBtn.addEventListener('click', () => {
    inputEl.value = '';
    outputEl.value = '';
    window.showToast('Cleared', 'info');
  });
};

/* ==========================================================================
   15. URL Encoder/Decoder
   ========================================================================== */
window.initUrlEncoderDecoder = function () {
  const inputEl = document.getElementById('url-input');
  const outputEl = document.getElementById('url-output');
  const encodeComponentBtn = document.getElementById('url-encode-comp-btn');
  const encodeFullBtn = document.getElementById('url-encode-full-btn');
  const decodeBtn = document.getElementById('url-decode-btn');
  const swapBtn = document.getElementById('url-swap-btn');
  const copyBtn = document.getElementById('copy-url-btn');
  const clearBtn = document.getElementById('clear-url-btn');

  if (!inputEl) return;

  encodeComponentBtn.addEventListener('click', () => {
    const val = inputEl.value;
    if (!val) return;
    outputEl.value = encodeURIComponent(val);
    window.showToast('Encoded as URL Component!', 'success');
  });

  encodeFullBtn.addEventListener('click', () => {
    const val = inputEl.value;
    if (!val) return;
    outputEl.value = encodeURI(val);
    window.showToast('Encoded as full URL!', 'success');
  });

  decodeBtn.addEventListener('click', () => {
    const val = inputEl.value;
    if (!val) return;
    try {
      outputEl.value = decodeURIComponent(val);
      window.showToast('Decoded URL!', 'success');
    } catch (err) {
      window.showToast('Invalid or malformed URL encoding.', 'error');
    }
  });

  swapBtn.addEventListener('click', () => {
    const temp = inputEl.value;
    inputEl.value = outputEl.value;
    outputEl.value = temp;
  });

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(outputEl.value, 'URL output copied!');
  });

  clearBtn.addEventListener('click', () => {
    inputEl.value = '';
    outputEl.value = '';
    window.showToast('Cleared', 'info');
  });
};
