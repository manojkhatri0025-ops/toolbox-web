﻿/**
 * ToolBox Web - PDF Tools Suite
 * 6. PDF Merger
 * 7. PDF Splitter
 * 
 * 100% Client-side processing using pdf-lib library (PDFLib).
 */

/* ==========================================================================
   6. PDF Merger
   ========================================================================== */
window.initPdfMerger = function () {
  const dropzone = document.getElementById('merger-dropzone');
  const fileInput = document.getElementById('merger-input');
  const fileListEl = document.getElementById('pdf-file-list');
  const mergeBtn = document.getElementById('merge-pdf-btn');
  const clearBtn = document.getElementById('clear-merger-btn');

  if (!dropzone || !fileInput) return;

  let pdfItems = []; // Array of { file, arrayBuffer, pageCount }

  window.setupDropzone(dropzone, fileInput, async (files) => {
    if (!window.PDFLib) {
      window.showToast('PDF processing library is loading. Please wait a moment.', 'error');
      return;
    }

    for (const file of files) {
      if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
        try {
          const buffer = await file.arrayBuffer();
          const pdfDoc = await window.PDFLib.PDFDocument.load(buffer);
          pdfItems.push({
            file: file,
            buffer: buffer,
            pageCount: pdfDoc.getPageCount()
          });
        } catch (err) {
          console.error(err);
          window.showToast(`Could not load ${file.name}. It may be encrypted or corrupted.`, 'error');
        }
      } else {
        window.showToast(`Skipped ${file.name}: not a PDF file.`, 'error');
      }
    }
    renderList();
  });

  function renderList() {
    fileListEl.innerHTML = '';
    if (pdfItems.length === 0) {
      mergeBtn.disabled = true;
      return;
    }
    mergeBtn.disabled = false;

    pdfItems.forEach((item, index) => {
      const card = document.createElement('div');
      card.className = 'tool-card';
      card.style.display = 'flex';
      card.style.flexDirection = 'row';
      card.style.alignItems = 'center';
      card.style.gap = '1rem';
      card.style.padding = '0.75rem 1rem';
      card.style.marginBottom = '0.5rem';

      card.innerHTML = `
        <div style="width: 40px; height: 40px; border-radius: 6px; background: var(--primary-light); color: var(--primary); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 0.8rem;">
          PDF
        </div>
        <div style="flex: 1; min-width: 0;">
          <div class="uploaded-file-name" style="font-weight: 600; font-size: 0.9rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"></div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${item.pageCount} pages • ${window.formatBytes(item.file.size)}</div>
        </div>
        <div style="display: flex; gap: 0.25rem;">
          <button class="btn btn-secondary btn-sm move-up-btn" data-index="${index}" ${index === 0 ? 'disabled' : ''} title="Move Up">↑</button>
          <button class="btn btn-secondary btn-sm move-down-btn" data-index="${index}" ${index === pdfItems.length - 1 ? 'disabled' : ''} title="Move Down">↓</button>
          <button class="btn btn-danger btn-sm remove-pdf-btn" data-index="${index}" title="Remove">✕</button>
        </div>
      `;
      card.querySelector('.uploaded-file-name').textContent = item.file.name;
      fileListEl.appendChild(card);
    });

    fileListEl.querySelectorAll('.move-up-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-index'), 10);
        if (idx > 0) {
          const temp = pdfItems[idx];
          pdfItems[idx] = pdfItems[idx - 1];
          pdfItems[idx - 1] = temp;
          renderList();
        }
      });
    });

    fileListEl.querySelectorAll('.move-down-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-index'), 10);
        if (idx < pdfItems.length - 1) {
          const temp = pdfItems[idx];
          pdfItems[idx] = pdfItems[idx + 1];
          pdfItems[idx + 1] = temp;
          renderList();
        }
      });
    });

    fileListEl.querySelectorAll('.remove-pdf-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-index'), 10);
        pdfItems.splice(idx, 1);
        renderList();
      });
    });
  }

  clearBtn.addEventListener('click', () => {
    pdfItems = [];
    fileInput.value = '';
    renderList();
  });

  mergeBtn.addEventListener('click', async () => {
    if (pdfItems.length < 2) {
      window.showToast('Please upload at least 2 PDF files to merge.', 'error');
      return;
    }

    mergeBtn.disabled = true;
    mergeBtn.textContent = 'Merging PDFs...';

    try {
      const mergedPdf = await window.PDFLib.PDFDocument.create();

      for (const item of pdfItems) {
        const doc = await window.PDFLib.PDFDocument.load(item.buffer);
        const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
        copiedPages.forEach(page => mergedPdf.addPage(page));
      }

      const mergedPdfBytes = await mergedPdf.save();
      const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'merged-document.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      window.showToast('PDFs merged and downloaded successfully!', 'success');
    } catch (err) {
      console.error(err);
      window.showToast('Error occurred while merging PDFs.', 'error');
    } finally {
      mergeBtn.disabled = false;
      mergeBtn.textContent = 'Merge PDFs & Download';
    }
  });
};

/* ==========================================================================
   7. PDF Splitter
   ========================================================================== */
window.initPdfSplitter = function () {
  const dropzone = document.getElementById('splitter-dropzone');
  const fileInput = document.getElementById('splitter-input');
  const workspace = document.getElementById('splitter-workspace');
  const docInfoEl = document.getElementById('pdf-doc-info');
  const pageRangeInput = document.getElementById('page-range-input');
  const splitBtn = document.getElementById('split-pdf-btn');
  const resetBtn = document.getElementById('reset-splitter-btn');

  if (!dropzone || !fileInput) return;

  let loadedPdfDoc = null;
  let loadedBuffer = null;
  let totalPages = 0;
  let currentFile = null;

  window.setupDropzone(dropzone, fileInput, async (files) => {
    if (files && files[0]) {
      const file = files[0];
      if (!file.type.startsWith('application/pdf') && !file.name.toLowerCase().endsWith('.pdf')) {
        window.showToast('Please upload a valid PDF document.', 'error');
        return;
      }
      if (!window.PDFLib) {
        window.showToast('PDF library is loading, please wait.', 'error');
        return;
      }

      try {
        currentFile = file;
        loadedBuffer = await file.arrayBuffer();
        loadedPdfDoc = await window.PDFLib.PDFDocument.load(loadedBuffer);
        totalPages = loadedPdfDoc.getPageCount();

        docInfoEl.textContent = `Uploaded: ${file.name} (${totalPages} pages • ${window.formatBytes(file.size)})`;
        pageRangeInput.value = totalPages > 1 ? `1-${Math.min(totalPages, 3)}` : '1';
        pageRangeInput.placeholder = `e.g. 1-3, 5, 8 (Max: ${totalPages})`;

        dropzone.style.display = 'none';
        workspace.style.display = 'block';
      } catch (err) {
        console.error(err);
        window.showToast('Unable to open this PDF. It may be encrypted or password-protected.', 'error');
      }
    }
  });

  // Parse human readable page range string into 0-indexed array
  function parsePageRanges(rangeStr, maxPages) {
    const pages = new Set();
    const parts = rangeStr.split(',');

    for (let part of parts) {
      part = part.trim();
      if (!part) continue;

      if (part.includes('-')) {
        const [startStr, endStr] = part.split('-');
        const start = parseInt(startStr.trim(), 10);
        const end = parseInt(endStr.trim(), 10);
        if (isNaN(start) || isNaN(end)) continue;

        const low = Math.max(1, Math.min(start, end));
        const high = Math.min(maxPages, Math.max(start, end));

        for (let i = low; i <= high; i++) {
          pages.add(i - 1); // 0-based
        }
      } else {
        const p = parseInt(part, 10);
        if (!isNaN(p) && p >= 1 && p <= maxPages) {
          pages.add(p - 1);
        }
      }
    }
    return Array.from(pages).sort((a, b) => a - b);
  }

  splitBtn.addEventListener('click', async () => {
    if (!loadedPdfDoc) return;

    const rangeStr = pageRangeInput.value.trim();
    if (!rangeStr) {
      window.showToast('Please specify the pages to extract (e.g. 1-3, 5).', 'error');
      return;
    }

    const selectedIndices = parsePageRanges(rangeStr, totalPages);
    if (selectedIndices.length === 0) {
      window.showToast(`Invalid page selection. Please enter page numbers between 1 and ${totalPages}.`, 'error');
      return;
    }

    splitBtn.disabled = true;
    splitBtn.textContent = 'Extracting Pages...';

    try {
      const newPdf = await window.PDFLib.PDFDocument.create();
      const copiedPages = await newPdf.copyPages(loadedPdfDoc, selectedIndices);
      copiedPages.forEach(p => newPdf.addPage(p));

      const pdfBytes = await newPdf.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `split-${currentFile.name.replace(/\.[^/.]+$/, '')}-pages.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      window.showToast(`Extracted ${selectedIndices.length} pages successfully!`, 'success');
    } catch (err) {
      console.error(err);
      window.showToast('Failed to split the PDF document.', 'error');
    } finally {
      splitBtn.disabled = false;
      splitBtn.textContent = 'Split & Download PDF';
    }
  });

  resetBtn.addEventListener('click', () => {
    loadedPdfDoc = null;
    loadedBuffer = null;
    currentFile = null;
    totalPages = 0;
    fileInput.value = '';
    workspace.style.display = 'none';
    dropzone.style.display = 'block';
  });
};
