﻿/**
 * ToolBox Web - Calculator Suite
 * 19. Standard & Scientific Calculator (Safe evaluation without eval())
 * 20. BMI Calculator (Metric & Imperial modes with visual gauge)
 */

/* ==========================================================================
   19. Safe Calculator (Recursive-Descent Expression Parser)
   ========================================================================== */
window.initCalculator = function () {
  const displayExpr = document.getElementById('calc-expr');
  const displayResult = document.getElementById('calc-result');
  const historyList = document.getElementById('calc-history-list');
  const modeToggleBtn = document.getElementById('calc-mode-toggle');
  const sciPad = document.getElementById('calc-sci-pad');

  if (!displayResult) return;

  let expr = '';
  let result = '0';
  let lastValue = null;
  let justCalculated = false;
  let history = [];
  let isScientific = false;

  // Toggle Scientific Pad
  if (modeToggleBtn && sciPad) {
    modeToggleBtn.addEventListener('click', () => {
      isScientific = !isScientific;
      sciPad.style.display = isScientific ? 'grid' : 'none';
      modeToggleBtn.textContent = isScientific ? 'Standard Mode' : 'Scientific Mode';
    });
  }

  // Parse only explicit mathematical tokens. No executable JavaScript is accepted.
  function safeEval(expression) {
    if (expression.length > 1000) throw new Error('Expression is too long.');
    const source = expression.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
    const tokens = [];
    let offset = 0;
    while (offset < source.length) {
      const rest = source.slice(offset);
      if (/^\s/.test(rest)) {
        offset++;
        continue;
      }
      // Scientific notation is a single number, distinct from the constant e.
      const number = rest.match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/);
      if (number) {
        tokens.push({ type: 'number', value: finite(Number(number[0])) });
        offset += number[0].length;
        continue;
      }
      const name = rest.match(/^[a-zA-Z]+/);
      if (name) {
        tokens.push({ type: 'name', value: name[0] });
        offset += name[0].length;
        continue;
      }
      const symbol = source[offset++];
      if (!'+-*/%^()π'.includes(symbol)) throw new Error('Invalid character in expression.');
      tokens.push({ type: symbol });
    }
    tokens.push({ type: 'end' });
    let position = 0;
    const functions = { sin: Math.sin, cos: Math.cos, tan: Math.tan,
      log: Math.log10, ln: Math.log, sqrt: Math.sqrt };

    function finite(value) {
      if (!Number.isFinite(value)) throw new Error('Result is outside the supported real-number range.');
      return value;
    }
    function take(type) {
      if (tokens[position].type !== type) return false;
      position++;
      return true;
    }
    function expect(type) {
      if (!take(type)) throw new Error(type === ')' ? 'Missing closing parenthesis.' : 'Expected ' + type + '.');
    }
    function sum() {
      let value = product();
      while (true) {
        if (take('+')) value = finite(value + product());
        else if (take('-')) value = finite(value - product());
        else return value;
      }
    }
    function product() {
      let value = unary();
      while (true) {
        if (take('*')) value = finite(value * unary());
        else if (take('/')) {
          const divisor = unary();
          if (divisor === 0) throw new Error('Division by zero.');
          value = finite(value / divisor);
        } else return value;
      }
    }
    // Powers bind before a leading sign: -2^2 = -(2^2), and 2^-2 is valid.
    function unary() {
      if (take('+')) return unary();
      if (take('-')) return -unary();
      return power();
    }
    function power() {
      const value = percentage();
      // Parsing the exponent through unary also makes powers right-associative.
      return take('^') ? finite(Math.pow(value, unary())) : value;
    }
    function percentage() {
      let value = primary();
      while (take('%')) value /= 100;
      return value;
    }
    function primary() {
      const token = tokens[position];
      if (take('number')) return token.value;
      if (take('π')) return Math.PI;
      if (take('(')) {
        const value = sum();
        expect(')');
        return value;
      }
      if (take('name')) {
        if (token.value === 'e') return Math.E;
        if (!Object.prototype.hasOwnProperty.call(functions, token.value)) {
          throw new Error('Unknown mathematical function.');
        }
        expect('(');
        const value = sum();
        expect(')');
        if ((token.value === 'ln' || token.value === 'log') && value <= 0) {
          throw new Error('Logarithms require a positive number.');
        }
        if (token.value === 'sqrt' && value < 0) throw new Error('Square roots require a non-negative number.');
        return finite(functions[token.value](value));
      }
      throw new Error('Expected a number, constant, or parenthesized expression.');
    }
    const value = sum();
    if (!take('end')) throw new Error('Invalid expression: check decimals, operators, and parentheses.');
    return finite(value);
  }

  // Round only the visible answer; continued calculations and history keep the value.
  function formatResult(value) {
    return Number(value.toPrecision(15)).toString();
  }

  function updateDisplay() {
    displayExpr.textContent = justCalculated ? result : expr;
    displayResult.textContent = result;
  }

  function handleInput(val) {
    if (val === 'C') {
      expr = '';
      result = '0';
      lastValue = null;
      justCalculated = false;
    } else if (val === 'DEL') {
      expr = expr.slice(0, -1);
      justCalculated = false;
    } else if (val === '=') {
      if (!expr) return;
      try {
        const calculated = safeEval(expr);
        result = formatResult(calculated);
        lastValue = calculated;
        history.unshift({ expr: expr, res: result, value: calculated });
        if (history.length > 8) history.pop();
        renderHistory();
        expr = String(calculated);
        justCalculated = true;
      } catch (err) {
        result = 'Error';
        justCalculated = false;
        window.showToast(err.message || 'Syntax Error', 'error');
      }
    } else {
      const isFunction = ['sin', 'cos', 'tan', 'log', 'ln', 'sqrt'].includes(val);
      if (justCalculated) {
        if (isFunction) {
          expr = val + '(' + String(lastValue) + ')';
          justCalculated = false;
          updateDisplay();
          return;
        }
        // A new number starts a fresh calculation; operators continue the exact answer.
        expr = /^[0-9.]$/.test(val) || ['π', 'e', '('].includes(val) ? '' : '(' + String(lastValue) + ')';
        justCalculated = false;
      }
      // Append character or function
      if (isFunction) {
        expr += val + '(';
      } else {
        expr += val;
      }
    }
    updateDisplay();
  }

  function renderHistory() {
    if (!historyList) return;
    historyList.innerHTML = '';
    history.forEach(item => {
      const entry = document.createElement('div');
      entry.style.padding = '0.4rem 0';
      entry.style.borderBottom = '1px solid var(--border-color)';
      entry.style.cursor = 'pointer';
      const expressionLabel = document.createElement('span');
      expressionLabel.style.color = 'var(--text-muted)';
      expressionLabel.style.fontSize = '0.85rem';
      expressionLabel.textContent = item.expr + ' = ';
      const answerLabel = document.createElement('strong');
      answerLabel.style.color = 'var(--primary)';
      answerLabel.textContent = item.res;
      entry.appendChild(expressionLabel);
      entry.appendChild(answerLabel);
      entry.addEventListener('click', () => {
        expr = String(item.value);
        lastValue = item.value;
        result = item.res;
        justCalculated = true;
        updateDisplay();
      });
      historyList.appendChild(entry);
    });
  }

  // Keyboard support
  window.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (document.activeElement && (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName) || document.activeElement.isContentEditable)) {
      return;
    }
    if (/^[0-9]$/.test(e.key)) {
      handleInput(e.key);
    } else if (['+', '-', '*', '/'].includes(e.key)) {
      handleInput(e.key === '*' ? '×' : (e.key === '/' ? '÷' : e.key));
    } else if (e.key === 'Enter' || e.key === '=') {
      e.preventDefault();
      handleInput('=');
    } else if (e.key === 'Backspace') {
      e.preventDefault();
      handleInput('DEL');
    } else if (e.key === 'Escape') {
      handleInput('C');
    } else if (['(', ')', '.', '%', '^', 'e'].includes(e.key)) {
      handleInput(e.key);
    }
  });

  // Wire buttons
  document.querySelectorAll('.calc-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.getAttribute('data-val');
      handleInput(val);
    });
  });

  updateDisplay();
};

/* ==========================================================================
   20. BMI Calculator
   ========================================================================== */
window.initBmiCalculator = function () {
  const metricRadio = document.getElementById('bmi-mode-metric');
  const imperialRadio = document.getElementById('bmi-mode-imperial');
  const metricBox = document.getElementById('bmi-metric-inputs');
  const imperialBox = document.getElementById('bmi-imperial-inputs');

  const heightCm = document.getElementById('bmi-height-cm');
  const weightKg = document.getElementById('bmi-weight-kg');

  const heightFt = document.getElementById('bmi-height-ft');
  const heightIn = document.getElementById('bmi-height-in');
  const weightLbs = document.getElementById('bmi-weight-lbs');

  const calculateBtn = document.getElementById('calculate-bmi-btn');
  const resetBtn = document.getElementById('reset-bmi-btn');

  const resultCard = document.getElementById('bmi-result-card');
  const bmiValueEl = document.getElementById('bmi-value');
  const bmiCategoryBadge = document.getElementById('bmi-category-badge');
  const bmiHealthyRangeEl = document.getElementById('bmi-healthy-range');
  const bmiMarker = document.getElementById('bmi-marker');

  if (!calculateBtn) return;

  function switchMode() {
    if (metricRadio.checked) {
      metricBox.style.display = 'grid';
      imperialBox.style.display = 'none';
    } else {
      metricBox.style.display = 'none';
      imperialBox.style.display = 'grid';
    }
  }

  metricRadio.addEventListener('change', switchMode);
  imperialRadio.addEventListener('change', switchMode);

  function calculateBmi() {
    let bmi = 0;
    let heightInMeters = 0;

    if (metricRadio.checked) {
      const cm = parseFloat(heightCm.value);
      const kg = parseFloat(weightKg.value);

      if (isNaN(cm) || cm <= 0 || isNaN(kg) || kg <= 0) {
        window.showToast('Please enter valid positive numbers for height and weight.', 'error');
        return;
      }
      heightInMeters = cm / 100;
      bmi = kg / (heightInMeters * heightInMeters);
    } else {
      const ft = parseFloat(heightFt.value) || 0;
      const inch = parseFloat(heightIn.value) || 0;
      const totalInches = (ft * 12) + inch;
      const lbs = parseFloat(weightLbs.value);

      if (totalInches <= 0 || isNaN(lbs) || lbs <= 0) {
        window.showToast('Please enter valid positive numbers for height and weight.', 'error');
        return;
      }
      heightInMeters = totalInches * 0.0254;
      bmi = (lbs / (totalInches * totalInches)) * 703;
    }

    bmi = parseFloat(bmi.toFixed(1));
    bmiValueEl.textContent = bmi.toString();

    // Determine category
    let category = '';
    let badgeClass = '';
    let markerPercent = 0;

    if (bmi < 18.5) {
      category = 'Underweight';
      badgeClass = 'btn-secondary';
      markerPercent = Math.min(25, (bmi / 18.5) * 25);
    } else if (bmi <= 24.9) {
      category = 'Normal weight';
      badgeClass = 'btn-success';
      markerPercent = 25 + (((bmi - 18.5) / (24.9 - 18.5)) * 25);
    } else if (bmi <= 29.9) {
      category = 'Overweight';
      badgeClass = 'btn-outline';
      markerPercent = 50 + (((bmi - 25.0) / (29.9 - 25.0)) * 25);
    } else {
      category = 'Obese';
      badgeClass = 'btn-danger';
      markerPercent = Math.min(100, 75 + (((bmi - 30.0) / 15) * 25));
    }

    bmiCategoryBadge.textContent = category;
    bmiCategoryBadge.className = `btn btn-sm ${badgeClass}`;
    bmiMarker.style.left = `${Math.max(2, Math.min(98, markerPercent))}%`;

    // Calculate healthy weight range for height
    if (metricRadio.checked) {
      const minKg = (18.5 * (heightInMeters * heightInMeters)).toFixed(1);
      const maxKg = (24.9 * (heightInMeters * heightInMeters)).toFixed(1);
      bmiHealthyRangeEl.textContent = `${minKg} kg – ${maxKg} kg`;
    } else {
      const minLbs = ((18.5 * (heightInMeters * heightInMeters)) * 2.20462).toFixed(1);
      const maxLbs = ((24.9 * (heightInMeters * heightInMeters)) * 2.20462).toFixed(1);
      bmiHealthyRangeEl.textContent = `${minLbs} lbs – ${maxLbs} lbs`;
    }

    resultCard.style.display = 'block';
    window.showToast(`BMI calculated: ${bmi} (${category})`, 'success');
  }

  calculateBtn.addEventListener('click', calculateBmi);

  resetBtn.addEventListener('click', () => {
    heightCm.value = '175';
    weightKg.value = '70';
    heightFt.value = '5';
    heightIn.value = '9';
    weightLbs.value = '154';
    resultCard.style.display = 'none';
  });

  // Initial calculation
  calculateBmi();
};
