﻿/**
 * ToolBox Web - Text & Security Tools Suite
 * 10. Password Generator
 * 11. Word & Character Counter
 * 12. Text Case Converter
 */

/* ==========================================================================
   10. Password Generator (Cryptographically Secure)
   ========================================================================== */
window.initPasswordGenerator = function () {
  const lengthSlider = document.getElementById('pw-length');
  const lengthVal = document.getElementById('pw-length-val');
  const incUpper = document.getElementById('pw-upper');
  const incLower = document.getElementById('pw-lower');
  const incNumbers = document.getElementById('pw-numbers');
  const incSymbols = document.getElementById('pw-symbols');
  const excAmbiguous = document.getElementById('pw-ambiguous');
  const pwDisplay = document.getElementById('pw-display');
  const copyBtn = document.getElementById('copy-pw-btn');
  const generateBtn = document.getElementById('generate-pw-btn');
  const strengthBar = document.getElementById('pw-strength-bar');
  const strengthLabel = document.getElementById('pw-strength-label');

  if (!pwDisplay) return;

  const UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const LOWER = 'abcdefghijklmnopqrstuvwxyz';
  const NUMBERS = '0123456789';
  const SYMBOLS = '!@#$%^&*()_+-=[]{}|;:,.<>?';
  const AMBIGUOUS = /[il1Lo0O]/g;

  function generatePassword() {
    const length = parseInt(lengthSlider.value, 10);
    lengthVal.textContent = length;

    let charset = '';
    if (incUpper.checked) charset += UPPER;
    if (incLower.checked) charset += LOWER;
    if (incNumbers.checked) charset += NUMBERS;
    if (incSymbols.checked) charset += SYMBOLS;

    if (excAmbiguous.checked) {
      charset = charset.replace(AMBIGUOUS, '');
    }

    if (!charset) {
      pwDisplay.value = 'Select at least one character type';
      updateStrength(0);
      return;
    }

    // Cryptographically secure random generation
    const randomBuffer = new Uint32Array(length);
    window.crypto.getRandomValues(randomBuffer);

    let password = '';
    for (let i = 0; i < length; i++) {
      password += charset[randomBuffer[i] % charset.length];
    }

    pwDisplay.value = password;
    updateStrength(calculateEntropy(password, charset.length));
  }

  function calculateEntropy(pwd, charsetSize) {
    if (!pwd || !charsetSize) return 0;
    return Math.round(pwd.length * (Math.log2(charsetSize)));
  }

  function updateStrength(entropy) {
    if (entropy <= 0) {
      strengthBar.style.width = '0%';
      strengthBar.style.backgroundColor = 'var(--text-light)';
      strengthLabel.textContent = 'None';
    } else if (entropy < 40) {
      strengthBar.style.width = '25%';
      strengthBar.style.backgroundColor = 'var(--danger)';
      strengthLabel.textContent = 'Weak';
      strengthLabel.style.color = 'var(--danger)';
    } else if (entropy < 65) {
      strengthBar.style.width = '50%';
      strengthBar.style.backgroundColor = 'var(--warning)';
      strengthLabel.textContent = 'Fair';
      strengthLabel.style.color = 'var(--warning)';
    } else if (entropy < 85) {
      strengthBar.style.width = '75%';
      strengthBar.style.backgroundColor = 'var(--accent)';
      strengthLabel.textContent = 'Good';
      strengthLabel.style.color = 'var(--accent)';
    } else {
      strengthBar.style.width = '100%';
      strengthBar.style.backgroundColor = 'var(--success)';
      strengthLabel.textContent = 'Very Strong';
      strengthLabel.style.color = 'var(--success)';
    }
  }

  lengthSlider.addEventListener('input', generatePassword);
  [incUpper, incLower, incNumbers, incSymbols, excAmbiguous].forEach(el => {
    el.addEventListener('change', generatePassword);
  });
  generateBtn.addEventListener('click', generatePassword);

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(pwDisplay.value, 'Password copied to clipboard!');
  });

  generatePassword();
};

/* ==========================================================================
   11. Word & Character Counter
   ========================================================================== */
window.initWordCounter = function () {
  const textArea = document.getElementById('wc-input');
  const wordCountEl = document.getElementById('wc-words');
  const charCountEl = document.getElementById('wc-chars');
  const charNoSpacesEl = document.getElementById('wc-chars-nospaces');
  const sentenceCountEl = document.getElementById('wc-sentences');
  const paragraphCountEl = document.getElementById('wc-paragraphs');
  const readingTimeEl = document.getElementById('wc-reading-time');
  const speakingTimeEl = document.getElementById('wc-speaking-time');
  const copyBtn = document.getElementById('copy-wc-btn');
  const clearBtn = document.getElementById('clear-wc-btn');

  if (!textArea) return;

  function updateCounts() {
    const text = textArea.value;

    // Characters
    const totalChars = text.length;
    const charsNoSpaces = text.replace(/\s+/g, '').length;

    // Words
    const wordsMatch = text.trim().match(/\S+/g);
    const wordCount = wordsMatch ? wordsMatch.length : 0;

    // Sentences
    const sentencesMatch = text.match(/[^.!?]+[.!?]+(\s|$)/g);
    const sentenceCount = sentencesMatch ? sentencesMatch.length : (text.trim() ? 1 : 0);

    // Paragraphs
    const paragraphsMatch = text.split(/\n+/).filter(p => p.trim().length > 0);
    const paragraphCount = paragraphsMatch.length;

    // Reading & Speaking Time
    const readMinutes = Math.ceil(wordCount / 200);
    const speakMinutes = Math.ceil(wordCount / 130);

    wordCountEl.textContent = wordCount.toLocaleString();
    charCountEl.textContent = totalChars.toLocaleString();
    charNoSpacesEl.textContent = charsNoSpaces.toLocaleString();
    sentenceCountEl.textContent = sentenceCount.toLocaleString();
    paragraphCountEl.textContent = paragraphCount.toLocaleString();
    readingTimeEl.textContent = wordCount === 0 ? '0 min' : `${readMinutes} min`;
    speakingTimeEl.textContent = wordCount === 0 ? '0 min' : `${speakMinutes} min`;
  }

  textArea.addEventListener('input', updateCounts);

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(textArea.value, 'Text copied to clipboard!');
  });

  clearBtn.addEventListener('click', () => {
    textArea.value = '';
    updateCounts();
    window.showToast('Text cleared', 'info');
  });

  updateCounts();
};

/* ==========================================================================
   12. Text Case Converter
   ========================================================================== */
window.initCaseConverter = function () {
  const textArea = document.getElementById('case-input');
  const copyBtn = document.getElementById('copy-case-btn');
  const clearBtn = document.getElementById('clear-case-btn');

  if (!textArea) return;

  function getWords(str) {
    // Keep Unicode letters, vowel/combining marks and Indic joiners together.
    // Split existing camelCase and acronym boundaries before changing case.
    const spaced = str
      .replace(/([\p{Ll}\p{N}]\p{M}*)(\p{Lu})/gu, '$1 $2')
      .replace(/(\p{Lu}\p{M}*)(\p{Lu}\p{M}*\p{Ll})/gu, '$1 $2');
    return spaced.match(/[\p{L}\p{M}\p{N}\u200C\u200D]+/gu) || [];
  }

  function capitalize(word) {
    return word.replace(/^\p{L}/u, letter => letter.toUpperCase());
  }

  const transforms = {
    upper: str => str.toUpperCase(),
    lower: str => str.toLowerCase(),
    title: str => {
      const minorWords = /^(a|an|and|as|at|but|by|en|for|if|in|nor|of|on|or|per|the|to|v[.]?|via|vs[.]?)$/i;
      let firstWord = true;
      return str.toLowerCase().replace(/[\p{L}\p{N}][\p{L}\p{M}\p{N}\u200C\u200D]*/gu, word => {
        const result = firstWord || !minorWords.test(word) ? capitalize(word) : word;
        firstWord = false;
        return result;
      });
    },
    sentence: str => {
      return str.toLowerCase().replace(/(^\s*|[.!?।॥]\s+)(\p{L})/gu, (match, prefix, letter) => prefix + letter.toUpperCase());
    },
    camel: str => {
      const words = getWords(str);
      return words.map((w, i) => i === 0 ? w.toLowerCase() : capitalize(w.toLowerCase())).join('');
    },
    pascal: str => {
      const words = getWords(str);
      return words.map(w => capitalize(w.toLowerCase())).join('');
    },
    snake: str => {
      const words = getWords(str);
      return words.map(w => w.toLowerCase()).join('_');
    },
    kebab: str => {
      const words = getWords(str);
      return words.map(w => w.toLowerCase()).join('-');
    },
    constant: str => {
      const words = getWords(str);
      return words.map(w => w.toUpperCase()).join('_');
    }
  };

  document.querySelectorAll('.btn-case-transform').forEach(btn => {
    btn.addEventListener('click', () => {
      const action = btn.getAttribute('data-case');
      if (transforms[action] && textArea.value) {
        textArea.value = transforms[action](textArea.value);
        window.showToast(`Converted to ${btn.textContent.trim()}!`, 'success');
      }
    });
  });

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(textArea.value, 'Text copied to clipboard!');
  });

  clearBtn.addEventListener('click', () => {
    textArea.value = '';
    window.showToast('Text cleared', 'info');
  });
};
