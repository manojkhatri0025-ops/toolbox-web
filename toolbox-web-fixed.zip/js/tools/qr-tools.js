﻿/**
 * ToolBox Web - QR Tools Suite
 * 8. QR Code Generator
 * 9. QR Code Scanner
 * 
 * Client-side QR generation via qrcode-generator and decoding via jsQR.
 */

/* ==========================================================================
   8. QR Code Generator
   ========================================================================== */
window.initQrGenerator = function () {
  const qrTypeSelect = document.getElementById('qr-type-select');
  const typePanels = document.querySelectorAll('.qr-type-panel');
  const sizeSelect = document.getElementById('qr-size');
  const fgColorInput = document.getElementById('qr-fg-color');
  const bgColorInput = document.getElementById('qr-bg-color');
  const eclSelect = document.getElementById('qr-ecl');
  const generateBtn = document.getElementById('generate-qr-btn');
  const qrResultWrapper = document.getElementById('qr-result-wrapper');
  const qrCanvas = document.getElementById('qr-canvas');
  const downloadPngBtn = document.getElementById('download-qr-png');

  if (!qrTypeSelect) return;

  // Switch input form based on type
  qrTypeSelect.addEventListener('change', () => {
    const val = qrTypeSelect.value;
    typePanels.forEach(panel => {
      panel.style.display = panel.id === `qr-panel-${val}` ? 'block' : 'none';
    });
  });

  function getQrText() {
    const type = qrTypeSelect.value;
    if (type === 'url') {
      let url = document.getElementById('qr-input-url').value.trim();
      if (url && !url.match(/^https?:\/\//i)) url = 'https://' + url;
      return url;
    } else if (type === 'text') {
      return document.getElementById('qr-input-text').value;
    } else if (type === 'email') {
      const email = document.getElementById('qr-input-email').value.trim();
      const subject = encodeURIComponent(document.getElementById('qr-input-email-sub').value.trim());
      return email ? `mailto:${email}${subject ? '?subject=' + subject : ''}` : '';
    } else if (type === 'phone') {
      const phone = document.getElementById('qr-input-phone').value.trim();
      return phone ? `tel:${phone}` : '';
    } else if (type === 'wifi') {
      // Spaces are significant in network names/passwords. Escape delimiters
      // so a semicolon or backslash does not become part of the WIFI format.
      const escapeWifi = value => value.replace(/[\\;,:\"]/g, character => '\\' + character);
      const ssid = escapeWifi(document.getElementById('qr-wifi-ssid').value);
      const pass = escapeWifi(document.getElementById('qr-wifi-pass').value);
      const enc = document.getElementById('qr-wifi-enc').value;
      const hidden = document.getElementById('qr-wifi-hidden').checked ? 'true' : 'false';
      return ssid ? `WIFI:T:${enc};S:${ssid};P:${pass};H:${hidden};;` : '';
    } else if (type === 'vcard') {
      const name = document.getElementById('qr-vcard-name').value.trim();
      const phone = document.getElementById('qr-vcard-phone').value.trim();
      const email = document.getElementById('qr-vcard-email').value.trim();
      const org = document.getElementById('qr-vcard-org').value.trim();
      return `BEGIN:VCARD\nVERSION:3.0\nN:${name}\nFN:${name}\nORG:${org}\nTEL:${phone}\nEMAIL:${email}\nEND:VCARD`;
    }
    return '';
  }

  function generateQr() {
    qrResultWrapper.style.display = 'none';
    const text = getQrText();
    if (!text.trim()) {
      window.showToast('Please enter the required information to generate QR code.', 'error');
      return;
    }

    const ecl = eclSelect.value || 'M';
    const size = parseInt(sizeSelect.value, 10) || 300;
    const fgColor = fgColorInput.value || '#000000';
    const bgColor = bgColorInput.value || '#ffffff';

    try {
      if (typeof qrcode === 'function') {
        // The library's default converter truncates Unicode to low bytes.
        // Byte mode must receive UTF-8 for Nepali, emoji and other scripts.
        qrcode.stringToBytes = value => Array.from(new TextEncoder().encode(value));
        const qr = qrcode(0, ecl);
        qr.addData(text, 'Byte');
        qr.make();

        const moduleCount = qr.getModuleCount();
        const cellSize = Math.max(1, Math.floor(size / (moduleCount + 8)));
        const margin = cellSize * 4;
        const totalSize = (moduleCount * cellSize) + (margin * 2);

        qrCanvas.width = totalSize;
        qrCanvas.height = totalSize;
        const ctx = qrCanvas.getContext('2d');

        // Draw background
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, totalSize, totalSize);

        // Draw modules
        ctx.fillStyle = fgColor;
        for (let row = 0; row < moduleCount; row++) {
          for (let col = 0; col < moduleCount; col++) {
            if (qr.isDark(row, col)) {
              ctx.fillRect(
                margin + (col * cellSize),
                margin + (row * cellSize),
                cellSize,
                cellSize
              );
            }
          }
        }

        qrResultWrapper.style.display = 'block';
        window.showToast('QR Code generated successfully!', 'success');
      } else {
        window.showToast('QR generator library is still loading. Please try again.', 'error');
      }
    } catch (err) {
      console.error(err);
      window.showToast('Error generating QR code. Content may be too long for selected error correction.', 'error');
    }
  }

  generateBtn.addEventListener('click', generateQr);

  downloadPngBtn.addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = qrCanvas.toDataURL('image/png');
    a.download = 'toolboxweb-qrcode.png';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.showToast('QR Code downloaded as PNG!', 'success');
  });

  // Initial trigger
  generateQr();
};

/* ==========================================================================
   9. QR Code Scanner
   ========================================================================== */
window.initQrScanner = function () {
  const video = document.getElementById('qr-video');
  const scanCanvas = document.getElementById('qr-scan-canvas');
  const startCameraBtn = document.getElementById('start-camera-btn');
  const stopCameraBtn = document.getElementById('stop-camera-btn');
  const dropzone = document.getElementById('qr-scanner-dropzone');
  const fileInput = document.getElementById('qr-scanner-input');
  const resultCard = document.getElementById('scanner-result-card');
  const resultText = document.getElementById('scanner-result-text');
  const copyBtn = document.getElementById('copy-scan-result-btn');
  const openUrlBtn = document.getElementById('open-scan-url-btn');

  if (!scanCanvas) return;

  let stream = null;
  let scanning = false;
  const ctx = scanCanvas.getContext('2d');

  function isValidHttpUrl(string) {
    let url;
    try {
      url = new URL(string);
    } catch (_) {
      return false;
    }
    return url.protocol === 'http:' || url.protocol === 'https:';
  }

  function handleScanResult(codeData) {
    resultText.value = codeData;
    resultCard.style.display = 'block';

    if (isValidHttpUrl(codeData)) {
      openUrlBtn.style.display = 'inline-flex';
      openUrlBtn.onclick = () => window.open(codeData, '_blank', 'noopener,noreferrer');
    } else {
      openUrlBtn.style.display = 'none';
    }

    window.showToast('QR Code detected!', 'success');
  }

  const cameraPlaceholder = document.getElementById('camera-placeholder');

  // Camera Scanning
  startCameraBtn.addEventListener('click', async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      window.showToast('Camera is not supported on this browser or context.', 'error');
      return;
    }

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      video.srcObject = stream;
      video.setAttribute('playsinline', true);
      video.style.display = 'block';
      if (cameraPlaceholder) cameraPlaceholder.style.display = 'none';
      await video.play();

      startCameraBtn.style.display = 'none';
      stopCameraBtn.style.display = 'inline-flex';
      scanning = true;
      requestAnimationFrame(tick);
    } catch (err) {
      console.error(err);
      window.showToast('Unable to access camera. Please grant camera permission or use image upload.', 'error');
    }
  });

  function stopCamera() {
    scanning = false;
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      stream = null;
    }
    video.style.display = 'none';
    if (cameraPlaceholder) cameraPlaceholder.style.display = 'block';
    startCameraBtn.style.display = 'inline-flex';
    stopCameraBtn.style.display = 'none';
  }

  stopCameraBtn.addEventListener('click', stopCamera);
  window.addEventListener('beforeunload', stopCamera);

  function tick() {
    if (!scanning) return;

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      scanCanvas.width = video.videoWidth;
      scanCanvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, scanCanvas.width, scanCanvas.height);
      const imageData = ctx.getImageData(0, 0, scanCanvas.width, scanCanvas.height);

      if (typeof jsQR === 'function') {
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert'
        });
        if (code && code.data) {
          handleScanResult(code.data);
          stopCamera();
          return;
        }
      }
    }
    requestAnimationFrame(tick);
  }

  // File Upload Scanning
  window.setupDropzone(dropzone, fileInput, (files) => {
    if (files && files[0]) {
      resultCard.style.display = 'none';
      resultText.value = '';
      openUrlBtn.style.display = 'none';
      const file = files[0];
      const reader = new FileReader();
      const showImageError = () => window.showToast('Unable to read this image. Please choose a valid image file.', 'error');
      reader.onerror = showImageError;
      reader.onabort = showImageError;
      reader.onload = (e) => {
        const img = new Image();
        img.onerror = showImageError;
        img.onload = () => {
          try {
            scanCanvas.width = img.naturalWidth;
            scanCanvas.height = img.naturalHeight;
            ctx.drawImage(img, 0, 0);
            const imageData = ctx.getImageData(0, 0, scanCanvas.width, scanCanvas.height);

            if (typeof jsQR === 'function') {
              const code = jsQR(imageData.data, imageData.width, imageData.height);
              if (code && code.data) {
                handleScanResult(code.data);
              } else {
                window.showToast('No readable QR code found in this image.', 'error');
              }
            } else {
              window.showToast('QR decoder library is still loading. Please try again.', 'error');
            }
          } catch (err) {
            console.error(err);
            showImageError();
          }
        };
        img.src = e.target.result;
      };
      try {
        reader.readAsDataURL(file);
      } catch (err) {
        showImageError();
      }
    }
  });

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(resultText.value, 'QR result copied to clipboard!');
  });
};
