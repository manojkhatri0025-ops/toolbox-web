/**
 * ToolBox Web - Utility Tools Suite
 * 16. Color Picker
 * 17. Unit Converter
 * 18. Timestamp Converter
 */

/* ==========================================================================
   16. Color Picker & Palette
   ========================================================================== */
window.initColorPicker = function () {
  const nativePicker = document.getElementById('native-color-picker');
  const previewBox = document.getElementById('color-preview-box');
  const hexInput = document.getElementById('color-hex-val');
  const rgbInput = document.getElementById('color-rgb-val');
  const hslInput = document.getElementById('color-hsl-val');
  const hsvInput = document.getElementById('color-hsv-val');
  const contrastWhiteEl = document.getElementById('contrast-white');
  const contrastBlackEl = document.getElementById('contrast-black');
  const randomBtn = document.getElementById('random-color-btn');
  const recentPaletteEl = document.getElementById('recent-palette');

  if (!nativePicker) return;

  const STORAGE_KEY = 'toolboxweb_recent_colors';

  // Conversion Helpers
  function hexToRgb(hex) {
    hex = hex.replace(/^#/, '');
    if (hex.length === 3) {
      hex = hex.split('').map(c => c + c).join('');
    }
    const num = parseInt(hex, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255
    };
  }

  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
      const hex = Math.round(x).toString(16);
      return hex.length === 1 ? '0' + hex : hex;
    }).join('');
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;

    if (max === min) {
      h = s = 0;
    } else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100)
    };
  }

  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const d = max - min;
    let h, s = max === 0 ? 0 : d / max, v = max;

    if (max === min) {
      h = 0;
    } else {
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      v: Math.round(v * 100)
    };
  }

  // Relative Luminance for WCAG Contrast
  function getLuminance(r, g, b) {
    const a = [r, g, b].map(v => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
  }

  function getContrastRatio(l1, l2) {
    const lighter = Math.max(l1, l2);
    const darker = Math.min(l1, l2);
    return (lighter + 0.05) / (darker + 0.05);
  }

  function updateColor(hex, saveRecent = true) {
    hex = hex.toUpperCase();
    if (!hex.startsWith('#')) hex = '#' + hex;
    nativePicker.value = hex;
    previewBox.style.backgroundColor = hex;

    const rgb = hexToRgb(hex);
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b);

    hexInput.value = hex;
    rgbInput.value = `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
    hslInput.value = `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`;
    hsvInput.value = `hsv(${hsv.h}, ${hsv.s}%, ${hsv.v}%)`;

    // Contrast calculations
    const lum = getLuminance(rgb.r, rgb.g, rgb.b);
    const contrastWhite = getContrastRatio(lum, 1.0).toFixed(2);
    const contrastBlack = getContrastRatio(lum, 0.0).toFixed(2);

    contrastWhiteEl.textContent = `${contrastWhite}:1 ${contrastWhite >= 4.5 ? '✓ Pass' : '✕ Fail'}`;
    contrastWhiteEl.style.color = contrastWhite >= 4.5 ? 'var(--success)' : 'var(--danger)';

    contrastBlackEl.textContent = `${contrastBlack}:1 ${contrastBlack >= 4.5 ? '✓ Pass' : '✕ Fail'}`;
    contrastBlackEl.style.color = contrastBlack >= 4.5 ? 'var(--success)' : 'var(--danger)';

    if (saveRecent) {
      saveToRecent(hex);
    }
  }

  function saveToRecent(hex) {
    let recents = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem('omnitools_recent_colors') || '[]');
    recents = [hex, ...recents.filter(c => c !== hex)].slice(0, 10);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(recents));
    renderRecent();
  }

  function renderRecent() {
    const recents = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem('omnitools_recent_colors') || '[]');
    recentPaletteEl.innerHTML = '';
    recents.forEach(color => {
      const dot = document.createElement('button');
      dot.className = 'recent-color-dot';
      dot.style.width = '32px';
      dot.style.height = '32px';
      dot.style.borderRadius = '50%';
      dot.style.backgroundColor = color;
      dot.style.border = '2px solid var(--border-color)';
      dot.style.cursor = 'pointer';
      dot.title = color;
      dot.addEventListener('click', () => updateColor(color, false));
      recentPaletteEl.appendChild(dot);
    });
  }

  nativePicker.addEventListener('input', (e) => updateColor(e.target.value));

  randomBtn.addEventListener('click', () => {
    const randomHex = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
    updateColor(randomHex);
  });

  // Copy buttons
  document.querySelectorAll('.copy-color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const val = document.getElementById(targetId).value;
      window.copyToClipboard(val, `Copied ${val} to clipboard!`);
    });
  });

  renderRecent();
  updateColor(nativePicker.value || '#4F46E5', false);
};

/* ==========================================================================
   17. Unit Converter
   ========================================================================== */
window.initUnitConverter = function () {
  const typeSelect = document.getElementById('unit-category');
  const fromSelect = document.getElementById('unit-from-select');
  const toSelect = document.getElementById('unit-to-select');
  const fromInput = document.getElementById('unit-from-input');
  const toInput = document.getElementById('unit-to-input');
  const swapBtn = document.getElementById('swap-units-btn');
  const copyBtn = document.getElementById('copy-unit-result-btn');

  if (!typeSelect) return;

  const UNITS = {
    length: {
      base: 'm',
      units: {
        m: { name: 'Meters (m)', factor: 1 },
        km: { name: 'Kilometers (km)', factor: 1000 },
        cm: { name: 'Centimeters (cm)', factor: 0.01 },
        mm: { name: 'Millimeters (mm)', factor: 0.001 },
        mi: { name: 'Miles (mi)', factor: 1609.344 },
        yd: { name: 'Yards (yd)', factor: 0.9144 },
        ft: { name: 'Feet (ft)', factor: 0.3048 },
        in: { name: 'Inches (in)', factor: 0.0254 },
        nm: { name: 'Nautical Miles (NM)', factor: 1852 }
      }
    },
    weight: {
      base: 'kg',
      units: {
        kg: { name: 'Kilograms (kg)', factor: 1 },
        g: { name: 'Grams (g)', factor: 0.001 },
        mg: { name: 'Milligrams (mg)', factor: 0.000001 },
        t: { name: 'Metric Tonnes (t)', factor: 1000 },
        lb: { name: 'Pounds (lb)', factor: 0.45359237 },
        oz: { name: 'Ounces (oz)', factor: 0.02834952 },
        st: { name: 'Stone (st)', factor: 6.350293 }
      }
    },
    temperature: {
      isTemp: true,
      units: {
        C: { name: 'Celsius (°C)' },
        F: { name: 'Fahrenheit (°F)' },
        K: { name: 'Kelvin (K)' }
      }
    },
    area: {
      base: 'sq_m',
      units: {
        sq_m: { name: 'Square Meters (m²)', factor: 1 },
        sq_km: { name: 'Square Kilometers (km²)', factor: 1000000 },
        sq_ft: { name: 'Square Feet (ft²)', factor: 0.092903 },
        sq_mi: { name: 'Square Miles (mi²)', factor: 2589988.11 },
        acre: { name: 'Acres', factor: 4046.856 },
        ha: { name: 'Hectares (ha)', factor: 10000 }
      }
    },
    volume: {
      base: 'l',
      units: {
        l: { name: 'Liters (L)', factor: 1 },
        ml: { name: 'Milliliters (mL)', factor: 0.001 },
        cu_m: { name: 'Cubic Meters (m³)', factor: 1000 },
        gal: { name: 'US Gallons (gal)', factor: 3.78541 },
        qt: { name: 'US Quarts (qt)', factor: 0.946353 },
        pt: { name: 'US Pints (pt)', factor: 0.473176 },
        cup: { name: 'US Cups', factor: 0.236588 }
      }
    },
    speed: {
      base: 'm_s',
      units: {
        m_s: { name: 'Meters per second (m/s)', factor: 1 },
        km_h: { name: 'Kilometers per hour (km/h)', factor: 0.277778 },
        mph: { name: 'Miles per hour (mph)', factor: 0.44704 },
        knot: { name: 'Knots (kn)', factor: 0.514444 },
        ft_s: { name: 'Feet per second (ft/s)', factor: 0.3048 }
      }
    },
    time: {
      base: 's',
      units: {
        s: { name: 'Seconds (s)', factor: 1 },
        ms: { name: 'Milliseconds (ms)', factor: 0.001 },
        min: { name: 'Minutes (min)', factor: 60 },
        h: { name: 'Hours (h)', factor: 3600 },
        d: { name: 'Days (d)', factor: 86400 },
        wk: { name: 'Weeks (wk)', factor: 604800 },
        yr: { name: 'Years (365 days)', factor: 31536000 }
      }
    },
    digital: {
      base: 'b',
      units: {
        b: { name: 'Bytes (B)', factor: 1 },
        bit: { name: 'Bits (b)', factor: 0.125 },
        kb: { name: 'Kilobytes (KB)', factor: 1024 },
        mb: { name: 'Megabytes (MB)', factor: 1048576 },
        gb: { name: 'Gigabytes (GB)', factor: 1073741824 },
        tb: { name: 'Terabytes (TB)', factor: 1099511627776 },
        pb: { name: 'Petabytes (PB)', factor: 1125899906842624 }
      }
    }
  };

  function populateUnitDropdowns() {
    const cat = typeSelect.value;
    const catData = UNITS[cat];
    fromSelect.innerHTML = '';
    toSelect.innerHTML = '';

    const keys = Object.keys(catData.units);
    keys.forEach((key, idx) => {
      const opt1 = document.createElement('option');
      opt1.value = key;
      opt1.textContent = catData.units[key].name;
      fromSelect.appendChild(opt1);

      const opt2 = document.createElement('option');
      opt2.value = key;
      opt2.textContent = catData.units[key].name;
      toSelect.appendChild(opt2);
    });

    if (keys.length > 1) {
      toSelect.selectedIndex = 1;
    }
    convert();
  }

  function convert() {
    const val = parseFloat(fromInput.value);
    if (isNaN(val)) {
      toInput.value = '';
      return;
    }

    const cat = typeSelect.value;
    const catData = UNITS[cat];
    const fromUnit = fromSelect.value;
    const toUnit = toSelect.value;

    if (fromUnit === toUnit) {
      toInput.value = val;
      return;
    }

    let result = 0;
    if (catData.isTemp) {
      // Temperature conversion
      let celsius = val;
      if (fromUnit === 'F') celsius = (val - 32) * (5 / 9);
      else if (fromUnit === 'K') celsius = val - 273.15;

      if (toUnit === 'C') result = celsius;
      else if (toUnit === 'F') result = (celsius * (9 / 5)) + 32;
      else if (toUnit === 'K') result = celsius + 273.15;
    } else {
      // Linear conversion via base unit
      const baseVal = val * catData.units[fromUnit].factor;
      result = baseVal / catData.units[toUnit].factor;
    }

    // Format output nicely
    if (Math.abs(result) < 0.000001 && result !== 0) {
      toInput.value = result.toExponential(6);
    } else {
      toInput.value = parseFloat(result.toFixed(8)).toString();
    }
  }

  typeSelect.addEventListener('change', populateUnitDropdowns);
  fromSelect.addEventListener('change', convert);
  toSelect.addEventListener('change', convert);
  fromInput.addEventListener('input', convert);

  swapBtn.addEventListener('click', () => {
    const temp = fromSelect.value;
    fromSelect.value = toSelect.value;
    toSelect.value = temp;
    convert();
  });

  copyBtn.addEventListener('click', () => {
    window.copyToClipboard(toInput.value, 'Converted value copied!');
  });

  populateUnitDropdowns();
};

/* ==========================================================================
   18. Timestamp Converter
   ========================================================================== */
window.initTimestampConverter = function () {
  const tsInput = document.getElementById('ts-input');
  const tsUnitSelect = document.getElementById('ts-unit');
  const convertTsBtn = document.getElementById('convert-ts-btn');
  const setNowBtn = document.getElementById('set-now-btn');
  const outLocal = document.getElementById('ts-out-local');
  const outUtc = document.getElementById('ts-out-utc');
  const outIso = document.getElementById('ts-out-iso');
  const outRelative = document.getElementById('ts-out-relative');

  // Date to Timestamp elements
  const datePickerInput = document.getElementById('date-picker-input');
  const convertDateBtn = document.getElementById('convert-date-btn');
  const outSec = document.getElementById('date-out-sec');
  const outMs = document.getElementById('date-out-ms');

  if (!tsInput) return;

  function timeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    const intervals = [
      { label: 'year', secs: 31536000 },
      { label: 'month', secs: 2592000 },
      { label: 'day', secs: 86400 },
      { label: 'hour', secs: 3600 },
      { label: 'minute', secs: 60 }
    ];

    const isFuture = seconds < 0;
    const absSeconds = Math.abs(seconds);

    if (absSeconds < 45) return 'just now';

    for (let i = 0; i < intervals.length; i++) {
      const count = Math.floor(absSeconds / intervals[i].secs);
      if (count >= 1) {
        const plural = count > 1 ? 's' : '';
        return isFuture ? `in ${count} ${intervals[i].label}${plural}` : `${count} ${intervals[i].label}${plural} ago`;
      }
    }
    return '';
  }

  function convertTimestamp() {
    let raw = tsInput.value.trim();
    if (!raw) return;

    let num = parseInt(raw, 10);
    if (isNaN(num)) {
      window.showToast('Invalid numeric timestamp.', 'error');
      return;
    }

    // Convert to milliseconds if seconds selected
    if (tsUnitSelect.value === 's') {
      num *= 1000;
    }

    const date = new Date(num);
    if (isNaN(date.getTime())) {
      window.showToast('Invalid timestamp value.', 'error');
      return;
    }

    outLocal.textContent = date.toString();
    outUtc.textContent = date.toUTCString();
    outIso.textContent = date.toISOString();
    outRelative.textContent = timeAgo(date);
  }

  function setNow() {
    const now = Date.now();
    tsInput.value = tsUnitSelect.value === 's' ? Math.floor(now / 1000) : now;
    convertTimestamp();
  }

  convertTsBtn.addEventListener('click', convertTimestamp);
  tsUnitSelect.addEventListener('change', convertTimestamp);
  setNowBtn.addEventListener('click', setNow);

  // Date to timestamp conversion
  function convertDateToTs() {
    const val = datePickerInput.value;
    if (!val) {
      window.showToast('Please select a date and time.', 'error');
      return;
    }
    const d = new Date(val);
    if (isNaN(d.getTime())) {
      window.showToast('Invalid date format.', 'error');
      return;
    }
    const ms = d.getTime();
    outSec.textContent = Math.floor(ms / 1000).toString();
    outMs.textContent = ms.toString();
  }

  convertDateBtn.addEventListener('click', convertDateToTs);

  // Initialize date picker with current local time
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  datePickerInput.value = now.toISOString().slice(0, 16);
  convertDateToTs();
  setNow();
};
