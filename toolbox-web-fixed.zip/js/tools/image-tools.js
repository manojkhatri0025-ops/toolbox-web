﻿/**
 * ToolBox Web - Image Tools Suite
 * 1. Image Compressor
 * 2. Image Resizer
 * 3. Image Converter
 * 4. Image Cropper
 * 5. Image to PDF
 * 
 * 100% Client-side processing using HTML5 Canvas and jsPDF (for PDF bundling).
 */

// Decode before showing a workspace or adding a PDF page. Both disk-read and
// image-decode failures must settle the promise so controls remain usable.
function readToolImage(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) {
      reject(new Error('Please select an image file.'));
      return;
    }
    const reader = new FileReader();
    reader.onerror = reader.onabort = () => reject(new Error('The image could not be read. Please select it again.'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('This image is damaged or its format is not supported by your browser. Try JPG, PNG, or WebP.'));
      image.onload = () => {
        if (!image.naturalWidth || !image.naturalHeight) {
          reject(new Error('This image has no usable dimensions.'));
          return;
        }
        resolve({ image, src: reader.result });
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/* ==========================================================================
   1. Image Compressor
   ========================================================================== */
window.initImageCompressor = function () {
  const dropzone = document.getElementById('compressor-dropzone');
  const fileInput = document.getElementById('compressor-input');
  const workspace = document.getElementById('compressor-workspace');
  const qualitySlider = document.getElementById('compress-quality');
  const qualityVal = document.getElementById('compress-quality-val');
  const origSizeEl = document.getElementById('orig-size');
  const compSizeEl = document.getElementById('comp-size');
  const savingsEl = document.getElementById('comp-savings');
  const origPreview = document.getElementById('orig-preview');
  const compPreview = document.getElementById('comp-preview');
  const downloadBtn = document.getElementById('download-compressed-btn');
  const resetBtn = document.getElementById('reset-compressor-btn');

  if (!dropzone || !fileInput) return;

  let currentFile = null;
  let loadedImage = null;
  let compressedBlob = null;

  window.setupDropzone(dropzone, fileInput, (files) => {
    if (files && files[0]) {
      return handleFile(files[0]);
    }
  });

  async function handleFile(file) {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      window.showToast('Please select a valid image file (JPG, PNG, WebP).', 'error');
      return;
    }
    try {
      const { image, src } = await readToolImage(file);
      currentFile = file;
      loadedImage = image;
      origSizeEl.textContent = window.formatBytes(file.size);
      origPreview.src = src;
      dropzone.style.display = 'none';
      workspace.style.display = 'block';
      compressImage();
    } catch (err) {
      window.showToast(err.message, 'error');
    }
  }

  function compressImage() {
    if (!loadedImage) return;

    const quality = parseInt(qualitySlider.value, 10) / 100;
    const isPng = currentFile.type === 'image/png';
    qualitySlider.disabled = isPng;
    qualityVal.textContent = isPng ? 'Lossless PNG' : qualitySlider.value + '%';
    downloadBtn.disabled = true;

    const canvas = document.createElement('canvas');
    canvas.width = loadedImage.naturalWidth;
    canvas.height = loadedImage.naturalHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(loadedImage, 0, 0);

    // Determine output format
    const outputType = currentFile.type;
    const sourceFile = currentFile;

    canvas.toBlob((blob) => {
      if (currentFile !== sourceFile) return;
      if (!blob) {
        window.showToast('This image is too large to export in your browser. Try a smaller image.', 'error');
        return;
      }
      // Keep the original PNG when lossless re-encoding cannot make it smaller.
      compressedBlob = isPng && blob.size >= sourceFile.size ? sourceFile : blob;
      downloadBtn.disabled = false;
      compSizeEl.textContent = window.formatBytes(compressedBlob.size);
      
      const savedBytes = currentFile.size - compressedBlob.size;
      const pct = Math.round((savedBytes / currentFile.size) * 100);
      if (pct > 0) {
        savingsEl.textContent = `-${pct}%`;
        savingsEl.style.color = 'var(--success)';
      } else {
        savingsEl.textContent = `+${Math.abs(pct)}%`;
        savingsEl.style.color = 'var(--text-muted)';
      }

      if (compPreview.src.startsWith('blob:')) URL.revokeObjectURL(compPreview.src);
      const blobUrl = URL.createObjectURL(compressedBlob);
      compPreview.src = blobUrl;
    }, outputType, quality);
  }

  qualitySlider.addEventListener('input', compressImage);

  downloadBtn.addEventListener('click', () => {
    if (!compressedBlob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(compressedBlob);
    const ext = compressedBlob.type === 'image/png' ? 'png' : (compressedBlob.type === 'image/webp' ? 'webp' : 'jpg');
    a.download = `compressed-${currentFile.name.replace(/\.[^/.]+$/, '')}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.showToast('Compressed image downloaded!', 'success');
  });

  resetBtn.addEventListener('click', () => {
    currentFile = null;
    loadedImage = null;
    compressedBlob = null;
    fileInput.value = '';
    workspace.style.display = 'none';
    dropzone.style.display = 'block';
  });
};

/* ==========================================================================
   2. Image Resizer
   ========================================================================== */
window.initImageResizer = function () {
  const dropzone = document.getElementById('resizer-dropzone');
  const fileInput = document.getElementById('resizer-input');
  const workspace = document.getElementById('resizer-workspace');
  const widthInput = document.getElementById('resize-width');
  const heightInput = document.getElementById('resize-height');
  const lockAspectCheck = document.getElementById('lock-aspect');
  const formatSelect = document.getElementById('resize-format');
  const previewCanvas = document.getElementById('resize-canvas');
  const downloadBtn = document.getElementById('download-resized-btn');
  const resetBtn = document.getElementById('reset-resizer-btn');
  const origDimensionsEl = document.getElementById('orig-dimensions');

  if (!dropzone || !fileInput) return;

  let loadedImage = null;
  let currentFile = null;
  let aspectRatio = 1;

  window.setupDropzone(dropzone, fileInput, (files) => {
    if (files && files[0]) {
      return handleFile(files[0]);
    }
  });

  async function handleFile(file) {
    try {
      const { image } = await readToolImage(file);
      currentFile = file;
      loadedImage = image;
      aspectRatio = image.naturalWidth / image.naturalHeight;
      origDimensionsEl.textContent = `${image.naturalWidth} × ${image.naturalHeight} px`;
      widthInput.value = image.naturalWidth;
      heightInput.value = image.naturalHeight;
      dropzone.style.display = 'none';
      workspace.style.display = 'block';
      updateCanvas();
    } catch (err) {
      window.showToast(err.message, 'error');
    }
  }

  function updateCanvas() {
    if (!loadedImage) return;
    const w = parseInt(widthInput.value, 10) || 1;
    const h = parseInt(heightInput.value, 10) || 1;

    previewCanvas.width = w;
    previewCanvas.height = h;
    const ctx = previewCanvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(loadedImage, 0, 0, w, h);
  }

  widthInput.addEventListener('input', () => {
    if (lockAspectCheck.checked && aspectRatio) {
      heightInput.value = Math.round(widthInput.value / aspectRatio);
    }
    updateCanvas();
  });

  heightInput.addEventListener('input', () => {
    if (lockAspectCheck.checked && aspectRatio) {
      widthInput.value = Math.round(heightInput.value * aspectRatio);
    }
    updateCanvas();
  });

  // Percentage resize quick buttons
  document.querySelectorAll('.btn-pct').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!loadedImage) return;
      const pct = parseFloat(btn.getAttribute('data-pct')) / 100;
      widthInput.value = Math.round(loadedImage.naturalWidth * pct);
      heightInput.value = Math.round(loadedImage.naturalHeight * pct);
      updateCanvas();
    });
  });

  downloadBtn.addEventListener('click', () => {
    if (!loadedImage) return;
    const format = formatSelect.value;
    const mimeType = format === 'png' ? 'image/png' : (format === 'webp' ? 'image/webp' : 'image/jpeg');

    previewCanvas.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `resized-${widthInput.value}x${heightInput.value}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.showToast('Resized image downloaded!', 'success');
    }, mimeType, 0.92);
  });

  resetBtn.addEventListener('click', () => {
    loadedImage = null;
    currentFile = null;
    fileInput.value = '';
    workspace.style.display = 'none';
    dropzone.style.display = 'block';
  });
};

/* ==========================================================================
   3. Image Converter
   ========================================================================== */
window.initImageConverter = function () {
  const dropzone = document.getElementById('converter-dropzone');
  const fileInput = document.getElementById('converter-input');
  const workspace = document.getElementById('converter-workspace');
  const targetFormatSelect = document.getElementById('target-format');
  const bgFillGroup = document.getElementById('bg-fill-group');
  const bgFillColor = document.getElementById('bg-fill-color');
  const qualitySlider = document.getElementById('convert-quality');
  const qualityVal = document.getElementById('convert-quality-val');
  const previewImg = document.getElementById('convert-preview');
  const downloadBtn = document.getElementById('download-converted-btn');
  const resetBtn = document.getElementById('reset-converter-btn');

  if (!dropzone || !fileInput) return;

  let loadedImage = null;
  let currentFile = null;

  window.setupDropzone(dropzone, fileInput, (files) => {
    if (files && files[0]) {
      return handleFile(files[0]);
    }
  });

  async function handleFile(file) {
    try {
      const { image, src } = await readToolImage(file);
      currentFile = file;
      loadedImage = image;
      previewImg.src = src;
      dropzone.style.display = 'none';
      workspace.style.display = 'block';
      updateFormatUI();
    } catch (err) {
      window.showToast(err.message, 'error');
    }
  }

  function updateFormatUI() {
    const fmt = targetFormatSelect.value;
    if (fmt === 'jpeg') {
      bgFillGroup.style.display = 'block';
    } else {
      bgFillGroup.style.display = 'none';
    }
  }

  targetFormatSelect.addEventListener('change', updateFormatUI);

  qualitySlider.addEventListener('input', () => {
    qualityVal.textContent = qualitySlider.value + '%';
  });

  downloadBtn.addEventListener('click', () => {
    if (!loadedImage) return;

    const fmt = targetFormatSelect.value;
    const quality = parseInt(qualitySlider.value, 10) / 100;
    const canvas = document.createElement('canvas');
    canvas.width = loadedImage.naturalWidth;
    canvas.height = loadedImage.naturalHeight;
    const ctx = canvas.getContext('2d');

    // Fill background if converting to JPEG
    if (fmt === 'jpeg') {
      ctx.fillStyle = bgFillColor.value || '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    ctx.drawImage(loadedImage, 0, 0);

    const mime = fmt === 'png' ? 'image/png' : (fmt === 'webp' ? 'image/webp' : 'image/jpeg');
    canvas.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `converted-${currentFile.name.replace(/\.[^/.]+$/, '')}.${fmt}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.showToast(`Converted to ${fmt.toUpperCase()} and downloaded!`, 'success');
    }, mime, quality);
  });

  resetBtn.addEventListener('click', () => {
    loadedImage = null;
    currentFile = null;
    fileInput.value = '';
    workspace.style.display = 'none';
    dropzone.style.display = 'block';
  });
};

/* ==========================================================================
   4. Image Cropper
   ========================================================================== */
window.initImageCropper = function () {
  const dropzone = document.getElementById('cropper-dropzone');
  const fileInput = document.getElementById('cropper-input');
  const workspace = document.getElementById('cropper-workspace');
  const cropCanvas = document.getElementById('crop-canvas');
  const aspectBtns = document.querySelectorAll('.crop-aspect-btn');
  const downloadBtn = document.getElementById('download-cropped-btn');
  const resetBtn = document.getElementById('reset-cropper-btn');
  const cropDimsEl = document.getElementById('crop-dimensions');

  if (!dropzone || !fileInput) return;

  let loadedImage = null;
  let currentFile = null;
  let crop = { x: 50, y: 50, w: 200, h: 200 };
  let selectedAspect = 'free'; // 'free', '1:1', '4:3', '16:9'
  let isDragging = false;
  let isResizing = false;
  let dragStart = { x: 0, y: 0 };
  let scale = 1;

  window.setupDropzone(dropzone, fileInput, (files) => {
    if (files && files[0]) {
      return handleFile(files[0]);
    }
  });

  async function handleFile(file) {
    try {
      const { image } = await readToolImage(file);
      currentFile = file;
      loadedImage = image;
      dropzone.style.display = 'none';
      workspace.style.display = 'block';
      initCropBox();
      draw();
    } catch (err) {
      window.showToast(err.message, 'error');
    }
  }

  function initCropBox() {
    const maxDisplayW = Math.max(1, Math.min(window.innerWidth - 80, 800));
    scale = loadedImage.naturalWidth > maxDisplayW ? maxDisplayW / loadedImage.naturalWidth : 1;
    cropCanvas.width = Math.max(1, Math.round(loadedImage.naturalWidth * scale));
    cropCanvas.height = Math.max(1, Math.round(loadedImage.naturalHeight * scale));

    const initialW = Math.round(cropCanvas.width * 0.7);
    const initialH = Math.round(cropCanvas.height * 0.7);
    crop = {
      x: Math.round((cropCanvas.width - initialW) / 2),
      y: Math.round((cropCanvas.height - initialH) / 2),
      w: initialW,
      h: initialH
    };
    applyAspectConstraint();
  }

  function applyAspectConstraint() {
    crop.x = Math.max(0, Math.min(crop.x, cropCanvas.width - 1));
    crop.y = Math.max(0, Math.min(crop.y, cropCanvas.height - 1));
    const maxW = cropCanvas.width - crop.x;
    const maxH = cropCanvas.height - crop.y;
    const ratio = { '1:1': 1, '4:3': 4 / 3, '16:9': 16 / 9 }[selectedAspect];
    if (ratio) {
      // Fit the pair together: clipping one dimension would break the preset.
      crop.w = Math.min(Math.max(1, crop.w), maxW, maxH * ratio);
      crop.h = crop.w / ratio;
    } else {
      crop.w = Math.min(Math.max(1, crop.w), maxW);
      crop.h = Math.min(Math.max(1, crop.h), maxH);
    }
  }

  function draw() {
    if (!loadedImage) return;
    const ctx = cropCanvas.getContext('2d');
    ctx.clearRect(0, 0, cropCanvas.width, cropCanvas.height);
    ctx.drawImage(loadedImage, 0, 0, cropCanvas.width, cropCanvas.height);

    // Dark overlay outside crop box
    ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
    ctx.fillRect(0, 0, cropCanvas.width, crop.y);
    ctx.fillRect(0, crop.y, crop.x, crop.h);
    ctx.fillRect(crop.x + crop.w, crop.y, cropCanvas.width - (crop.x + crop.w), crop.h);
    ctx.fillRect(0, crop.y + crop.h, cropCanvas.width, cropCanvas.height - (crop.y + crop.h));

    // Crop box outline
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.strokeRect(crop.x, crop.y, crop.w, crop.h);

    // Crop handles at corners
    ctx.fillStyle = 'var(--primary, #4f46e5)';
    const handleSize = 10;
    // Bottom right resize handle
    ctx.fillRect(crop.x + crop.w - handleSize, crop.y + crop.h - handleSize, handleSize, handleSize);

    // Real output dimensions
    const realW = Math.round(crop.w / scale);
    const realH = Math.round(crop.h / scale);
    cropDimsEl.textContent = `${realW} × ${realH} px`;
  }

  // Mouse / Touch handlers for Crop Box
  function getPos(e) {
    const rect = cropCanvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * (cropCanvas.width / rect.width),
      y: (clientY - rect.top) * (cropCanvas.height / rect.height)
    };
  }

  cropCanvas.addEventListener('mousedown', startInteraction);
  cropCanvas.addEventListener('touchstart', startInteraction, { passive: false });

  function startInteraction(e) {
    if (!loadedImage) return;
    if (e.cancelable) e.preventDefault();
    const pos = getPos(e);
    // Check if near bottom right corner (resize)
    if (pos.x >= crop.x + crop.w - 20 && pos.x <= crop.x + crop.w + 10 &&
        pos.y >= crop.y + crop.h - 20 && pos.y <= crop.y + crop.h + 10) {
      isResizing = true;
      dragStart = pos;
    } else if (pos.x >= crop.x && pos.x <= crop.x + crop.w &&
               pos.y >= crop.y && pos.y <= crop.y + crop.h) {
      isDragging = true;
      dragStart = { x: pos.x - crop.x, y: pos.y - crop.y };
    }
  }

  window.addEventListener('mousemove', handleMove);
  window.addEventListener('touchmove', handleMove, { passive: false });

  function handleMove(e) {
    if (!isDragging && !isResizing) return;
    if (e.cancelable) e.preventDefault();
    const pos = getPos(e);

    if (isDragging) {
      crop.x = Math.max(0, Math.min(cropCanvas.width - crop.w, pos.x - dragStart.x));
      crop.y = Math.max(0, Math.min(cropCanvas.height - crop.h, pos.y - dragStart.y));
    } else if (isResizing) {
      const availableW = cropCanvas.width - crop.x;
      const availableH = cropCanvas.height - crop.y;
      crop.w = Math.min(availableW, Math.max(Math.min(40, availableW), pos.x - crop.x));
      if (selectedAspect === 'free') {
        crop.h = Math.min(availableH, Math.max(Math.min(40, availableH), pos.y - crop.y));
      }
      applyAspectConstraint();
    }
    draw();
  }

  window.addEventListener('mouseup', endInteraction);
  window.addEventListener('touchend', endInteraction);

  function endInteraction() {
    isDragging = false;
    isResizing = false;
  }

  aspectBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      aspectBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedAspect = btn.getAttribute('data-aspect');
      applyAspectConstraint();
      draw();
    });
  });

  downloadBtn.addEventListener('click', () => {
    if (!loadedImage) return;
    const realX = Math.round(crop.x / scale);
    const realY = Math.round(crop.y / scale);
    const realW = Math.round(crop.w / scale);
    const realH = Math.round(crop.h / scale);

    const outCanvas = document.createElement('canvas');
    outCanvas.width = realW;
    outCanvas.height = realH;
    const outCtx = outCanvas.getContext('2d');
    outCtx.drawImage(loadedImage, realX, realY, realW, realH, 0, 0, realW, realH);

    outCanvas.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `cropped-${realW}x${realH}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.showToast('Cropped image downloaded!', 'success');
    }, 'image/png');
  });

  resetBtn.addEventListener('click', () => {
    loadedImage = null;
    currentFile = null;
    fileInput.value = '';
    workspace.style.display = 'none';
    dropzone.style.display = 'block';
  });
};

/* ==========================================================================
   5. Image to PDF
   ========================================================================== */
window.initImageToPdf = function () {
  const dropzone = document.getElementById('img2pdf-dropzone');
  const fileInput = document.getElementById('img2pdf-input');
  const imageListEl = document.getElementById('img2pdf-list');
  const generateBtn = document.getElementById('generate-pdf-btn');
  const clearBtn = document.getElementById('clear-img2pdf-btn');
  const pageSizeSelect = document.getElementById('pdf-page-size');
  const orientationSelect = document.getElementById('pdf-orientation');
  const marginSelect = document.getElementById('pdf-margin');

  if (!dropzone || !fileInput) return;

  let imageFiles = [];
  let pendingLoads = 0;
  let queueVersion = 0;
  let generating = false;

  window.setupDropzone(dropzone, fileInput, async (files) => {
    const version = queueVersion;
    pendingLoads++;
    renderList();
    try {
      for (const file of Array.from(files)) {
        try {
          const { image, src } = await readToolImage(file);
          if (version !== queueVersion) break;
          imageFiles.push({ file, src, image });
        } catch (err) {
          if (version !== queueVersion) break;
          window.showToast(`${file.name}: ${err.message}`, 'error');
        }
      }
    } finally {
      pendingLoads--;
      renderList();
    }
  });

  function renderList() {
    imageListEl.innerHTML = '';
    if (imageFiles.length === 0) {
      generateBtn.disabled = true;
      return;
    }
    generateBtn.disabled = pendingLoads > 0 || generating;

    imageFiles.forEach((item, index) => {
      const card = document.createElement('div');
      card.className = 'tool-card';
      card.style.display = 'flex';
      card.style.flexDirection = 'row';
      card.style.alignItems = 'center';
      card.style.gap = '1rem';
      card.style.padding = '0.75rem 1rem';
      card.style.marginBottom = '0.5rem';

      card.innerHTML = `
        <img class="uploaded-image-preview" alt="Selected image" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px;">
        <div style="flex: 1; min-width: 0;">
          <div class="uploaded-file-name" style="font-weight: 600; font-size: 0.9rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"></div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${window.formatBytes(item.file.size)}</div>
        </div>
        <div style="display: flex; gap: 0.25rem;">
          <button class="btn btn-secondary btn-sm move-up-btn" data-index="${index}" ${index === 0 ? 'disabled' : ''} title="Move Up">↑</button>
          <button class="btn btn-secondary btn-sm move-down-btn" data-index="${index}" ${index === imageFiles.length - 1 ? 'disabled' : ''} title="Move Down">↓</button>
          <button class="btn btn-danger btn-sm remove-img-btn" data-index="${index}" title="Remove">✕</button>
        </div>
      `;
      card.querySelector('.uploaded-image-preview').src = item.src;
      card.querySelector('.uploaded-file-name').textContent = item.file.name;
      imageListEl.appendChild(card);
    });

    // Wire action buttons
    imageListEl.querySelectorAll('.move-up-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-index'), 10);
        if (idx > 0) {
          const temp = imageFiles[idx];
          imageFiles[idx] = imageFiles[idx - 1];
          imageFiles[idx - 1] = temp;
          renderList();
        }
      });
    });

    imageListEl.querySelectorAll('.move-down-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-index'), 10);
        if (idx < imageFiles.length - 1) {
          const temp = imageFiles[idx];
          imageFiles[idx] = imageFiles[idx + 1];
          imageFiles[idx + 1] = temp;
          renderList();
        }
      });
    });

    imageListEl.querySelectorAll('.remove-img-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-index'), 10);
        imageFiles.splice(idx, 1);
        renderList();
      });
    });
  }

  clearBtn.addEventListener('click', () => {
    queueVersion++;
    imageFiles = [];
    fileInput.value = '';
    renderList();
  });

  generateBtn.addEventListener('click', async () => {
    if (imageFiles.length === 0 || pendingLoads > 0 || generating) return;
    if (!window.jspdf || !window.jspdf.jsPDF) {
      window.showToast('PDF generator library is still loading. Please try again.', 'error');
      return;
    }

    const pages = imageFiles.slice();
    generating = true;
    generateBtn.disabled = true;
    generateBtn.textContent = 'Generating PDF...';

    try {
      const pageSize = pageSizeSelect.value; // 'a4', 'letter'
      const orientation = orientationSelect.value; // 'p' or 'l'
      const margin = parseInt(marginSelect.value, 10); // in mm

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({
        orientation: orientation,
        unit: 'mm',
        format: pageSize
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      for (let i = 0; i < pages.length; i++) {
        if (i > 0) doc.addPage();
        const item = pages[i];

        // Images were decoded before entering the queue, including error handling.
        const img = item.image;

        const maxW = pageWidth - (margin * 2);
        const maxH = pageHeight - (margin * 2);

        const imgAspect = img.naturalWidth / img.naturalHeight;
        let renderW = maxW;
        let renderH = renderW / imgAspect;

        if (renderH > maxH) {
          renderH = maxH;
          renderW = renderH * imgAspect;
        }

        const posX = margin + ((maxW - renderW) / 2);
        const posY = margin + ((maxH - renderH) / 2);

        if (item.file.type === 'image/jpeg') {
          doc.addImage(item.src, 'JPEG', posX, posY, renderW, renderH);
        } else {
          // Normalize browser-supported formats to PNG and retain transparency.
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          canvas.getContext('2d').drawImage(img, 0, 0);
          doc.addImage(canvas, 'PNG', posX, posY, renderW, renderH);
        }
      }

      doc.save('toolboxweb-images.pdf');
      window.showToast('PDF generated and downloaded successfully!', 'success');
    } catch (err) {
      console.error(err);
      window.showToast('Failed to generate PDF. Please verify your images.', 'error');
    } finally {
      generating = false;
      generateBtn.disabled = imageFiles.length === 0 || pendingLoads > 0;
      generateBtn.textContent = 'Convert to PDF & Download';
    }
  });
};
