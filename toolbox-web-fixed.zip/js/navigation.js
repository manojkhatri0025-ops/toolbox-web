﻿/**
 * ToolBox Web - Navigation & Header Interaction
 * Mobile hamburger menu, category dropdowns, keyboard navigation, and active link states.
 */
document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  const mobileToggle = document.querySelector('.mobile-toggle-btn');
  const navMenu = document.querySelector('.nav-menu');
  const navDropdowns = document.querySelectorAll('.nav-dropdown');

  // Mobile drawer toggle
  if (mobileToggle && navMenu) {
    const setMenuOpen = (open) => {
      navMenu.classList.toggle('open', open);
      mobileToggle.setAttribute('aria-expanded', String(open));
      mobileToggle.setAttribute('aria-label', open ? 'Close mobile navigation' : 'Open mobile navigation');
      document.body.style.overflow = open ? 'hidden' : '';
      if (!open) navDropdowns.forEach(dropdown => dropdown.classList.remove('open'));
    };

    mobileToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      setMenuOpen(!navMenu.classList.contains('open'));
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (navMenu.classList.contains('open') && !navMenu.contains(e.target) && !mobileToggle.contains(e.target)) {
        setMenuOpen(false);
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && navMenu.classList.contains('open')) {
        setMenuOpen(false);
        mobileToggle.focus();
      }
    });

    navMenu.addEventListener('click', (e) => {
      const link = e.target.closest('a');
      if (link && !link.classList.contains('nav-dropdown-toggle')) setMenuOpen(false);
    });

    window.matchMedia('(max-width: 768px)').addEventListener('change', () => setMenuOpen(false));
  }

  // Dropdown toggle on touch / mobile devices
  navDropdowns.forEach(dropdown => {
    const toggleBtn = dropdown.querySelector('.nav-dropdown-toggle');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', (e) => {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          dropdown.classList.toggle('open');
        }
      });
    }
  });

  // Highlight active link based on current path
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.nav-link, .dropdown-link');
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href) return;
    // Normalize comparison
    const cleanHref = href.replace(/^(\.\.\/|\.\/)/, '');
    const cleanCurrent = currentPath.split('/').pop();
    if (cleanCurrent && (cleanHref === cleanCurrent || href.endsWith(cleanCurrent))) {
      link.classList.add('active');
    }
  });
});
